package com.Logistic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogisticColApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogisticColApplication.class, args);
	}

}
