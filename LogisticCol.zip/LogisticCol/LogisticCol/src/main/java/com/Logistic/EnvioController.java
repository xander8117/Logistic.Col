package com.Logistic;

import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.Parameter;

import java.util.ArrayList; 
import java.util.List;

@Tag(name = "Gestión de Envíos", description = "API para gestionar recogidas, entregas y rastreo de envíos")
@RestController
@RequestMapping("/API")
public class EnvioController {

    private List<Envio> envios = new ArrayList<>();
    
    @Operation(
    summary = "Registrar recogida",
    description = "Permite registrar una nueva orden de recogida en el sistema"
    )
    @ApiResponse(responseCode = "200", description = "Recogida registrada correctamente")
    
    @PostMapping("/pickup")
    public Envio registrarRecogida(@RequestBody Envio envio){
    
        envio.setEstado("RECOGIDA REGISTRADA");
        envio.add(envio);
        
        return envio;
    }

    
    @Operation(
    summary = "Programar entrega",
    description = "Permite programar la entrega de un envío"
    )
    @ApiResponse(responseCode = "200", description = "Entrega programada correctamente")
    
    @PostMapping("/delivery")
    public Envio programarEntrega(@RequestBody Envio envio){
        
        envio.setEstado("ENTREGA PROGRAMADA");
        envios.add(envio);
        
        return envio;
    }
    
    
    @Operation(
    summary = "Consultar estado del envío",
    description = "Permite rastrear un envío utilizando su identificador"
    )
    
    @GetMapping("/tracking/{id}")
    public Envio rastrarEnvio(@PathVariable Long id){
    
        for (Envio envio : envios){
            if (envio.getId().equals(id)){
                return envio;
            }
        
        }
    
        return null;
    }
    
    
    @Operation(
    summary = "Obtener prueba de entrega",
    description = "Retorna la confirmación de entrega de un envío"
    )
    
    
    @GetMapping("/proof/{id}")
    public String pruebaEntrega(@PathVariable Long id){
    
        return "Entrega confirmada para el envio" + id;
    }
    
    
}
