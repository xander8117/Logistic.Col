package com.Logistic;

//Representa los datos que maneja la API

public class Envio {

    private Long id;
    private String direccionRecogida;
    private String direccionEntregada;
    private String estado;
    
    public Envio(){
    
    }
    
    public Envio(Long id, String direccionRecogida, String direccionEntregada, String estado){
        this.id = id;
        this.direccionRecogida = direccionRecogida;
        this.direccionEntregada = direccionEntregada;
        this.estado = estado;
    }
    
    
    public Long getId(){
        return id;
    }
    
    public String getDireccionRecogida(){
        return direccionRecogida;
    }
    
    public String getDireccionEntregada(){
        return direccionEntregada;
    }
    
    public String getEstado(){
        return estado;
    }    
    
    public void setId(Long id) {
        this.id = id;
    }

    public void setDireccionRecogida(String direccionRecogida) {
        this.direccionRecogida = direccionRecogida;
    }

    public void setDireccionEntregada(String direccionEntregada) {
        this.direccionEntregada = direccionEntregada;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    void add(Envio envio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
        
    
}
