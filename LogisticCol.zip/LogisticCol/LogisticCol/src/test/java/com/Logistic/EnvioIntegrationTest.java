
package com.Logistic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvioIntegrationTest {

    @Test
    void contextLoads() {
    }

}