package com.Logistic;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EnvioController.class)
public class EnvioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testRegistrarRecogida() throws Exception {

        Envio envio = new Envio(1L,"Bogotá","Medellín","");

        mockMvc.perform(post("/api/pickup")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(envio)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("RECOGIDA REGISTRADA"));
    }

    @Test
    void testProgramarEntrega() throws Exception {

        Envio envio = new Envio(2L,"Bogotá","Cali","");

        mockMvc.perform(post("/api/delivery")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(envio)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("ENTREGA PROGRAMADA"));
    }

}